btn.onclick = function() {
    var buscar = document.getElementById("buscar").value;
    if (buscar == "hola") {
        panel.innerHTML = "pendejo";
    } else if (buscar == "prueba"){
        panel.innerHTML = "pruba mesta";
        }
    else {
        panel.innerHTML = "No se Ha Encotrado Ningun Resultado Asegurate De Escribir Bien"
    }
}
