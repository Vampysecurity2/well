/* code by
Vampy Security */ 

document.getElementById("pues").innerHTML = "prueba"